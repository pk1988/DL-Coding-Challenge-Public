//
//  ViewController.swift
//  DL_Coding_Challenge
//
//  Created by Poorva Karandikar on 3/8/17.
//  Copyright © 2017 Poorva Karandikar. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var titleImage: UIImageView!
    @IBOutlet weak var temperature: UILabel!
    @IBOutlet weak var city: UILabel!
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func viewWillAppear(_ animated: Bool) {
        if WeatherDataManager.cityName != nil {
            print("\(WeatherDataManager.cityName)=\(WeatherDataManager.temperature)")
            
            if let temperature = WeatherDataManager.temperature{
                self.temperature?.text = temperature
            }
            
            if let city = WeatherDataManager.cityName{
                self.city?.text = city
            }
            
            
            if (WeatherDataManager.weatherDescription?.contains("Rain"))!{
                self.titleImage?.image = UIImage(named: "Rainy")
                
                if !(Gradient.checkSulayers(view: self.view, layerName: "Rainy")) {
                    Gradient.init(view: self.view, layerName: "Rainy", topRed: 153, topGreen: 177, topBlue: 195, botRed: 43, botGreen: 58, botBlue: 90)
                }
                
            } else if (WeatherDataManager.weatherDescription?.contains("Clear"))! {
                self.titleImage?.image = UIImage(named: "Sunny")
                if !(Gradient.checkSulayers(view: self.view, layerName: "Sunny")) {
                    Gradient.init(view: self.view, layerName: "Sunny", topRed: 253, topGreen: 245, topBlue: 62, botRed: 251, botGreen: 168, botBlue: 46)
                }
                
            } else if (WeatherDataManager.weatherDescription?.contains("Cloud"))!{
                self.titleImage?.image = UIImage(named: "Cloudy")
                if !(Gradient.checkSulayers(view: self.view, layerName: "Cloudy")) {
                    Gradient.init(view: self.view, layerName: "Cloudy", topRed: 97, topGreen: 97, topBlue: 97, botRed: 255, botGreen: 255, botBlue: 255)
                }
                
            }
        }
        
        tableView?.reloadData()
    }
    
    
    //MARK: TableView
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return WeatherDataManager.weeklyForecast.count
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "weatherCell", for: indexPath) as! WeatherTableViewCell
        
        let (date, tempMin, tempMax, descrip) = WeatherDataManager.weeklyForecast[indexPath.row]
        cell.dateLabel.text = date
        cell.tempLabel.text = ("\(tempMax)/\(tempMin)")
        if descrip.contains("Clear"){
            cell.weatherImageView.image = UIImage(named:"Sunny")
        } else if descrip.contains("Rain"){
            cell.weatherImageView.image = UIImage(named:"Rainy")
        } else if descrip.contains("Cloud"){
            cell.weatherImageView.image = UIImage(named:"Cloudy")
        }
        
        tableView.backgroundColor = .clear
        cell.backgroundColor = .clear
        tableView.tableFooterView = UIView()
        
        return cell
    }


}

