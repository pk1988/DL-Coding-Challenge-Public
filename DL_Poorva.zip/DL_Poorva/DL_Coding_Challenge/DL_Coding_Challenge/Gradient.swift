//
//  Gradient.swift
//  DL_Coding_Challenge
//
//  Created by Poorva Karandikar on 3/8/17.
//  Copyright © 2017 Poorva Karandikar. All rights reserved.
//

import UIKit

class Gradient: NSObject {
    
    var view:UIView = UIView()
    var layerName: String = ""
    var topRed: CGFloat = 255
    var topGreen: CGFloat = 255
    var topBlue: CGFloat = 255
    var botRed: CGFloat = 255
    var botGreen: CGFloat = 255
    var botBlue: CGFloat = 255
    
    var gradients:[CAGradientLayer] = []
    
    init(view:UIView, layerName:String, topRed: CGFloat, topGreen: CGFloat, topBlue: CGFloat, botRed: CGFloat, botGreen: CGFloat, botBlue: CGFloat) {
        super.init()
        self.topRed = topRed
        self.topGreen = topGreen
        self.topBlue = topBlue
        self.botRed = botRed
        self.botGreen = botGreen
        self.botBlue = botBlue
        self.view = view
        self.layerName = layerName
        
        applyGradient()
    }
    
    
    func applyGradient(){
        let topColor = UIColor(red: self.topRed/255, green: self.topGreen/255, blue: self.topBlue/255, alpha: 1.0)
        let botColor = UIColor(red: self.botRed/255, green: self.botGreen/255, blue: self.botBlue/255, alpha: 1.0)
        
        let gradientColors = [topColor.cgColor, botColor.cgColor]
        let gradientLocations:[NSNumber] = [0.0,1.0]
        
        let gradientLayer: CAGradientLayer = CAGradientLayer()
        gradientLayer.colors = gradientColors
        gradientLayer.locations = gradientLocations
        
        gradientLayer.name = self.layerName
        gradientLayer.frame = self.view.bounds
        gradients.append(gradientLayer)
        self.view.layer.insertSublayer(gradientLayer, at: 0)
        
        
    }
    
    static func checkSulayers(view:UIView, layerName:String) -> Bool{
        
        var layerNames = ["Sunny", "Cloudy", "Rainy"]
        layerNames = layerNames.filter{$0 != layerName}
        var layerFound = false
        if let layers = view.layer.sublayers{
            for layer in layers {
                if(layer.name == layerName){
                    let caGradientLayer = layer as! CAGradientLayer
                    caGradientLayer.setNeedsDisplay()
                    layerFound = true
                    print("working gradient =\(layer.name)")
                } else if (layer.name != nil && layerNames.contains(layer.name!)){
                    layer.removeFromSuperlayer()
                    print("gradient =\(layer.name)")
                    
                }
            }
        }
        return layerFound
    }
}
