//
//  SwitchViewController.swift
//  DL_Coding_Challenge
//
//  Created by Poorva Karandikar on 3/8/17.
//  Copyright © 2017 Poorva Karandikar. All rights reserved.
//

import UIKit

class SwitchViewController: UIViewController {

    @IBOutlet weak var newCity: UITextField!
    @IBOutlet weak var cityIsLabel: UILabel!
    
    var cityString: String!
    var state: String!
    var newURL: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func addCity(_ sender: Any) {
        getWeatherURLFromZipCode(zipCode: self.newCity.text!, completion: {
            jsonString in
            self.newURL = jsonString
            self.populateWeatherData(urlString: self.newURL)
        })
    }
    
    func getWeatherURLFromZipCode(zipCode: String, completion: @escaping (String) -> ()){
        let zipCode = zipCode
        let urlInitial = "http://api.wunderground.com/api/52eb161f094bd0b8/geolookup/q/\(zipCode).json"
        print("urlInitial=\(urlInitial)")
        
        //start call to get data
        if let url = URL(string: urlInitial){
            URLSession.shared.dataTask(with: url, completionHandler: {
                (data, respnse, error) in
                
                if let error = error {
                    print("Error retrieving data \(error)")
                } else {
                    if let data = data {
                        
                        let json = JSON(data:data)
                        
                        let jsonCity = json["location"]["city"].stringValue
                        self.cityString = jsonCity.replacingOccurrences(of: " ", with: "_")
                        
                        let jsonState = json["location"]["state"].stringValue
                        self.state = jsonState
                        
                        let jsonNewURL = "http://api.wunderground.com/api/52eb161f094bd0b8/conditions/q/\(self.state!)/\(self.cityString!).json"
                        completion(jsonNewURL)
                    }
                    
                }
            }).resume()
            //end call to get data
        }
        
    }

    func populateWeatherData(urlString: String){
        let urlString = urlString
        
        //start call to get data
        if let url = URL(string: urlString){
            URLSession.shared.dataTask(with: url, completionHandler: {
                (data, respnse, error) in
                
                if let error = error {
                    print("Error retrieving data \(error)")
                } else {
                    if let data = data {
                        
                        let json = JSON(data:data)
                        print(json)
                        
                        let cityName = json["current_observation"]["display_location"]["city"].stringValue
                        print("TEMPERATURE STRING \(cityName)")
                        
                        let stateName = json["current_observation"]["display_location"]["state"].stringValue
                        print("TEMPERATURE STRING \(stateName)")
                        
                        let temperature = json["current_observation"]["temperature_string"].stringValue
                        print("TEMPERATURE STRING \(temperature)")
                        
                        let weatherDescription = json["current_observation"]["weather"].stringValue
                        print("WEATHER DESCRIPTION \(weatherDescription)")
                        
                        let feelsLikeDescription = json["current_observation"]["feelslike_string"].stringValue
                        print("FEELS LIKE DESCRIPTION \(feelsLikeDescription)")
                        
                        
                        if temperature != "" && weatherDescription != "" && feelsLikeDescription != "" && cityName != "" && stateName != "" {
                            print("temperature \(temperature), weatherDescription \(weatherDescription), feelsLikeDescription \(feelsLikeDescription)")
                            // add to DataManager
                            WeatherDataManager.temperature = temperature
                            WeatherDataManager.weatherDescription = weatherDescription
                            WeatherDataManager.feelsLikeTemp = feelsLikeDescription
                            WeatherDataManager.cityName = cityName
                            WeatherDataManager.stateName = stateName
                            
                            DispatchQueue.main.async {
                                self.newCity.text = ("\(cityName), \(stateName)")
                                self.cityIsLabel.text = ("\(cityName), \(stateName)")
                                self.getMultidayForecast(cityName: cityName.replacingOccurrences(of: " ", with: "_"), stateName: stateName)
                            }
                        } else {
                            WeatherDataManager.temperature = nil
                            WeatherDataManager.weatherDescription = nil
                            WeatherDataManager.feelsLikeTemp = nil
                            WeatherDataManager.cityName = nil
                            WeatherDataManager.stateName = nil
                            
                            DispatchQueue.main.async {
                                self.newCity.text = ("No weather data for this city")
                                self.cityIsLabel.text = "Try again"
                            }
                        }
                        
                    }
                    
                }
            }).resume()
            //end call to get data
        }
        
    }
    
    
    func getMultidayForecast(cityName: String, stateName: String){
        
        let initialURL  = "http://api.wunderground.com/api/52eb161f094bd0b8/forecast10day/q/\(stateName)/\(cityName).json"
        if let url = URL(string: initialURL){
            URLSession.shared.dataTask(with: url, completionHandler: {
                (data, respnse, error) in
                
                if let error = error {
                    print("Error retrieving data \(error)")
                } else {
                    if let data = data {
                        
                        let json = JSON(data:data)
                        
                        WeatherDataManager.weeklyForecast.removeAll()
                        
                        for index in 1...7 {
                            let temperatureMin1 = json["forecast"]["simpleforecast"]["forecastday"][index]["low"]["fahrenheit"].stringValue + "°F"
                            
                            let temperatureMax1 = json["forecast"]["simpleforecast"]["forecastday"][index]["high"]["fahrenheit"].stringValue + "°F"
                            
                            let description1 = json["forecast"]["simpleforecast"]["forecastday"][index]["conditions"].stringValue
                            
                            let daysDate1 = json["forecast"]["simpleforecast"]["forecastday"][index]["date"]["weekday"].stringValue + " " + json["forecast"]["simpleforecast"]["forecastday"][index]["date"]["month"].stringValue + "/" + json["forecast"]["simpleforecast"]["forecastday"][index]["date"]["day"].stringValue
                            
                            WeatherDataManager.weeklyForecast.append((daysDate1,temperatureMin1,temperatureMax1,description1))
                            
                            print("DATE::\(daysDate1), MIN::\(temperatureMin1), MAX::\(temperatureMax1), DESC::\(description1)")
                        }
                    } else {
                        print ("No multiday forecast")
                    }
                    
                }
            }).resume()
            //end call to get data
        }
    }


}
