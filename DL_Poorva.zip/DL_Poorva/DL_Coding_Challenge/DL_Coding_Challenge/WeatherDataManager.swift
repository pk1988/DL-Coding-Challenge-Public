//
//  WeatherDataManager.swift
//  DL_Coding_Challenge
//
//  Created by Poorva Karandikar on 3/8/17.
//  Copyright © 2017 Poorva Karandikar. All rights reserved.
//

import UIKit

class WeatherDataManager: NSObject {
    static var temperature:String?
    static var feelsLikeTemp:String?
    static var cityName:String?
    static var stateName:String?
    static var weatherDescription:String?
    
    static var weeklyForecast = [(String,String,String,String)]()
}

